CA*_template:	original template files downloaded from CANVAS
runs:		implementations and solutoins
CA*_submission: some files that required submission

Note, "CA3_submission" is part of "runs", I just created this folder to make everything clear. To run the whole code, please go to "runs/code/". The solusions are stored in "runs/sols/".
